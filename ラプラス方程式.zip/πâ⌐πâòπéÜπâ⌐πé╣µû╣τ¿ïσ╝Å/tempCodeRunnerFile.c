// for(int i=1;i<=mesh.np;i++){
    //     double sum=0.0;
    //     for(int j=1;j<=mesh.np;j++){
    //         sum+=A[i][j];
    //     }
    //     printf("%f\n",sum);
    // }
